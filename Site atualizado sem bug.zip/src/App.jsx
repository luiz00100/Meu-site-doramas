import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';

// Páginas públicas / usuário
import Login from '@/pages/Login';
import Signup from '@/pages/Signup';
import Dashboard from '@/pages/Dashboard';
import DoramaDetail from '@/pages/DoramaDetail';
import DoramaWatch from '@/pages/DoramaWatch';
import SubscriptionPlans from '@/pages/SubscriptionPlans';
import CheckoutSuccess from '@/pages/CheckoutSuccess';
import CheckoutCanceled from '@/pages/CheckoutCanceled';
import TesteBunny from '@/pages/TesteBunny';
import AdminDoramas from '@/pages/AdminDoramas';
import AdminRedirect from '@/pages/AdminRedirect';
import ProtectedRoute from '@/components/ProtectedRoute';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import ExclusiveDoramas from '@/pages/ExclusiveDoramas';
import NewDoramas from '@/pages/NewDoramas';
import RecommendedDoramas from '@/pages/RecommendedDoramas';
import DubbedDoramas from '@/pages/DubbedDoramas';

// Admin
import AdminLogin from '@/pages/AdminLogin';
import AdminDashboard from '@/pages/AdminDashboard';
import AdminUsers from '@/pages/AdminUsers';
import AdminProtectedRoute from '@/components/AdminProtectedRoute';
import AdminRoute from '@/components/AdminRoute';

// Premium
import PremiumGuard from '@/components/PremiumGuard';

// Landing
import Landing from '@/pages/Landing';

function App() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <>
      <Helmet>
        <title>DoramaStream - Assista seus Dramas Asiáticos Favoritos</title>
        <meta
          name="description"
          content="Assista aos melhores doramas coreanos e asiáticos online. Descubra novos shows, assista seus favoritos e nunca perca um episódio."
        />
      </Helmet>

      <AuthProvider>
        <Router>
          <Routes>

            {/* Dashboard como página principal */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Dashboard searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
                </ProtectedRoute>
              }
            />

            <Route path="/landing" element={<Landing />} />

            {/* Auth */}
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            {/* Categorias */}
            <Route path="/exclusivos" element={<ProtectedRoute><ExclusiveDoramas /></ProtectedRoute>} />
            <Route path="/novos" element={<ProtectedRoute><NewDoramas /></ProtectedRoute>} />
            <Route path="/recomendados" element={<ProtectedRoute><RecommendedDoramas /></ProtectedRoute>} />
            <Route path="/dublados" element={<ProtectedRoute><DubbedDoramas /></ProtectedRoute>} />

            {/* Planos */}
            <Route path="/plans" element={<ProtectedRoute><SubscriptionPlans /></ProtectedRoute>} />

            {/* Doramas */}
            <Route path="/dorama/:id" element={<ProtectedRoute><DoramaDetail /></ProtectedRoute>} />

            {/* Watch com PremiumGuard */}
            <Route
              path="/dorama/:id/watch"
              element={
                <ProtectedRoute>
                  <PremiumGuard>
                    <DoramaWatch />
                  </PremiumGuard>
                </ProtectedRoute>
              }
            />

            {/* Outros */}
            <Route path="/teste-bunny" element={<TesteBunny />} />
            <Route path="/checkout/sucesso" element={<ProtectedRoute><CheckoutSuccess /></ProtectedRoute>} />
            <Route path="/checkout/cancelado" element={<ProtectedRoute><CheckoutCanceled /></ProtectedRoute>} />

            {/* Admin */}
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
            <Route path="/admin/dashboard" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
            <Route path="/admin/doramas" element={<AdminRoute><AdminDoramas /></AdminRoute>} />
            <Route path="/admin/users" element={<AdminRoute><AdminUsers /></AdminRoute>} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />

          </Routes>
        </Router>
      </AuthProvider>

      <Toaster />
    </>
  );
}

export default App;
