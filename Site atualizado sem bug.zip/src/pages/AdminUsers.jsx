import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Wrench } from 'lucide-react';

const AdminUsers = () => {
  return (
    <>
      <Helmet>
        <title>Gerenciar Usuários - Painel Administrativo</title>
      </Helmet>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
        <div className="text-center">
          <Wrench className="mx-auto h-16 w-16 text-purple-400 mb-4 animate-pulse" />
          <h1 className="text-3xl font-bold text-slate-100 mb-2">
            Página em Construção
          </h1>
          <p className="text-slate-400 mb-6">
            A funcionalidade de gerenciamento de usuários está sendo desenvolvida.
          </p>
          <Link to="/admin/dashboard">
            <Button variant="outline" className="border-slate-700 hover:bg-slate-800">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Painel
            </Button>
          </Link>
        </div>
      </div>
    </>
  );
};

export default AdminUsers;