import React from 'react';

export default function TesteBunny() {
  return (
    <div style={{width:"100%", maxWidth:"1000px", margin:"40px auto", aspectRatio:"16/9", position:"relative", background:"#000"}}>
      <iframe src="https://iframe.mediadelivery.net/play/549745/d9008190-6969-4149-8bbf-59c4ae7db7f6" allow="autoplay; fullscreen" style={{position:"absolute", top:0, left:0, width:"100%", height:"100%", border:0}}></iframe>
    </div>
  );
}