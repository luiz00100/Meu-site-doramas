import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Check, Loader2, CreditCard, Star } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const SubscriptionPlans = () => {
  const { toast } = useToast();
  const { session } = useAuth();
  const [loadingPlan, setLoadingPlan] = useState(null);

  const handleSubscribe = async (planType) => {
    setLoadingPlan(planType);
    try {
      if (!session) {
        toast({
          variant: "destructive",
          title: "Autenticação necessária",
          description: "Por favor, faça login para assinar.",
        });
        return;
      }

      const { data, error } = await supabase.functions.invoke('create-checkout-session', {
        body: { plan: planType },
        headers: {
          Authorization: `Bearer ${session.access_token}`
        }
      });

      if (error) throw error;

      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error('URL de checkout não retornada');
      }

    } catch (error) {
      console.error('Erro ao iniciar assinatura:', error);
      toast({
        variant: "destructive",
        title: "Erro na assinatura",
        description: "Erro ao iniciar assinatura, tente novamente.",
      });
    } finally {
      setLoadingPlan(null);
    }
  };

  return (
    <>
      <Helmet>
        <title>Planos de Assinatura - DoramaStream</title>
        <meta name="description" content="Escolha o melhor plano para assistir seus doramas favoritos." />
      </Helmet>

      <div className="min-h-screen bg-slate-950 text-slate-100">
        <Navbar isAuthenticated={true} />

        <div className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center mb-12">
            <motion.h1 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold text-white mb-4"
            >
              Escolha seu Plano
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-slate-400 text-lg"
            >
              Acesso ilimitado a milhares de doramas, sem anúncios.
            </motion.p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Plan 1: Monthly */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-8 flex flex-col hover:border-purple-500/50 transition-colors relative"
            >
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-white mb-2">DoramaPlay Padrão</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-purple-400">R$ 14,90</span>
                  <span className="text-slate-400">/mês</span>
                </div>
              </div>

              <ul className="space-y-4 mb-8 flex-1">
                {['Acesso ilimitado', 'Sem anúncios', 'Qualidade HD', 'Assista em qualquer lugar'].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-300">
                    <div className="bg-purple-500/20 rounded-full p-1">
                      <Check className="w-4 h-4 text-purple-400" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                onClick={() => handleSubscribe('monthly')}
                disabled={!!loadingPlan}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white py-6 text-lg font-medium"
              >
                {loadingPlan === 'monthly' ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  "Assinar DormaPlay Padrão – R$ 14,90"
                )}
              </Button>
            </motion.div>

            {/* Plan 2: Quarterly */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gradient-to-b from-purple-900/20 to-slate-900 border border-purple-500/30 rounded-2xl p-8 flex flex-col relative overflow-hidden"
            >
              <div className="absolute top-4 right-4 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                <Star className="w-3 h-3" fill="currentColor" />
                MELHOR VALOR
              </div>

              <div className="mb-6">
                <h3 className="text-2xl font-bold text-white mb-2">DoramaPlay Trimestral</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-purple-400">R$ 39,90</span>
                  <span className="text-slate-400">/3 meses</span>
                </div>
                <p className="text-sm text-green-400 mt-2 font-medium">Economize 10% comparado ao mensal</p>
              </div>

              <ul className="space-y-4 mb-8 flex-1">
                {['Tudo do plano Padrão', 'Prioridade no suporte', 'Downloads offline (em breve)', 'Economia garantida'].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-300">
                    <div className="bg-purple-500/20 rounded-full p-1">
                      <Check className="w-4 h-4 text-purple-400" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                onClick={() => handleSubscribe('quarterly')}
                disabled={!!loadingPlan}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 text-lg font-medium shadow-lg shadow-purple-900/20"
              >
                 {loadingPlan === 'quarterly' ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  "Assinar DormaPlay Trimestral – R$ 39,90"
                )}
              </Button>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SubscriptionPlans;