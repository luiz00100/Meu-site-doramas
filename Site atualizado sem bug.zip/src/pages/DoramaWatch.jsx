import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Navigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Crown, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';

export default function DoramaWatch() {
  const { id: slugFromUrl } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated, isPremium, checkingPremium } = useAuth();

  const [dorama, setDorama] = useState(null);
  const [loadingDorama, setLoadingDorama] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchDorama = async () => {
      setLoadingDorama(true);
      try {
        if (!slugFromUrl) {
          setError(true);
          setLoadingDorama(false);
          return;
        }

        const normalizedSlug = decodeURIComponent(slugFromUrl).trim().toLowerCase();

        const { data, error: queryError } = await supabase
          .from('doramas')
          .select('*')
          .eq('slug', normalizedSlug)
          .single();

        if (queryError || !data) {
          setError(true);
        } else {
          setDorama(data);
        }
      } catch (err) {
        setError(true);
      } finally {
        setLoadingDorama(false);
      }
    };

    fetchDorama();
  }, [slugFromUrl]);

  // Se não estiver autenticado, manda pro login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Carregando dorama ou checando premium
  if (loadingDorama || checkingPremium) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center text-white">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400 mr-2" />
        <div className="animate-pulse">Carregando...</div>
      </div>
    );
  }

  if (error || !dorama) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center text-white gap-4 p-4">
        <h2 className="text-xl font-semibold text-red-400">Vídeo não encontrado</h2>
        <p className="text-slate-400 text-center max-w-md">
          Não foi possível carregar o vídeo para "{slugFromUrl}".
        </p>
        <Button
          onClick={() => navigate('/dashboard')}
          variant="outline"
          className="bg-slate-900 border-slate-800 hover:bg-slate-800 text-slate-200"
        >
          <ArrowLeft className="w-4 h-4 mr-2" /> Voltar para o Catálogo
        </Button>
      </div>
    );
  }

  const videoUrl = (dorama.bunny_embed_url || '').trim();

  return (
    <>
      <Helmet>
        <title>{dorama.title ? `Assistindo: ${dorama.title}` : 'Assistir Dorama'}</title>
        <meta name="description" content={`Assista ao dorama ${dorama.title} online.`} />
      </Helmet>

      <div className="min-h-screen bg-black flex flex-col text-slate-100">
        {/* Topo */}
        <header className="p-4 flex items-center justify-start z-10 shrink-0">
          <Button
            onClick={() => navigate(`/dorama/${dorama.slug}`)}
            variant="ghost"
            className="text-slate-300 hover:text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5 mr-2" /> Voltar
          </Button>
        </header>

        {/* Player */}
        <main className="flex-1 flex flex-col items-center justify-start w-full bg-black">
          <div className="w-full max-w-5xl mx-auto px-0 sm:px-4">
            {/* ⚠️ ESSA DIV AGORA USA A CLASSE GLOBAL .watch-player-wrapper */}
            <div className="watch-player-wrapper">
              <div className="absolute inset-0 bg-black overflow-hidden rounded-none sm:rounded-lg">
                {!isPremium ? (
                  <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center text-slate-300 p-6 text-center">
                    <Crown className="w-16 h-16 text-yellow-400 mb-4" />
                    <h2 className="text-2xl font-bold text-white mb-2">Assinatura necessária</h2>
                    <p className="max-w-md mb-6 text-slate-400">
                      Você precisa ser assinante DoramaPlay para assistir a este conteúdo.
                    </p>
                    <Button
                      onClick={() => navigate('/plans')}
                      className="bg-purple-600 hover:bg-purple-700 text-white font-bold"
                      size="lg"
                    >
                      Assinar agora
                    </Button>
                  </div>
                ) : videoUrl ? (
                  <iframe
                    src={videoUrl}
                    title={dorama.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                    allowFullScreen
                    loading="lazy"
                    className="w-full h-full border-0 block"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center text-slate-500">
                    <p>Vídeo indisponível no momento.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {isPremium && (
            <p className="mt-4 text-center text-sm md:text-base font-medium text-purple-400 px-4 pb-6">
              Dica: toque duas vezes no vídeo para alternar a tela cheia.
            </p>
          )}
        </main>
      </div>
    </>
  );
}