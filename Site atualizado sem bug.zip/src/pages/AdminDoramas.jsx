import React, { useEffect, useState, useRef } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Trash2, Edit, Search, Plus, Save, X, Image as ImageIcon, Sparkles, Star, BadgeCheck, Globe, Layers, MonitorPlay } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

export default function AdminDoramas() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const bannerInputRef = useRef(null);
  
  // Admin data state
  const [doramas, setDoramas] = useState([]);
  const [loadingData, setLoadingData] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');

  // Form state
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editingSlug, setEditingSlug] = useState('');
  const [originalTitle, setOriginalTitle] = useState('');
  
  // File states
  const [coverFile, setCoverFile] = useState(null);
  const [bannerFile, setBannerFile] = useState(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    release_year: '',
    genres: '',
    cover_url: '',
    banner_url: '',
    bunny_embed_url: '',
    is_exclusive: false,
    is_new: false,
    is_featured: false,
    language: 'legendado'
  });

  // Constants
  const ADMIN_EMAIL = "tessuportegeral@gmail.com";
  const isAuthorized = !authLoading && user?.email === ADMIN_EMAIL;

  // Filter Tabs Configuration
  const filterTabs = [
    { id: 'all', label: 'Todos', icon: Layers },
    { id: 'exclusive', label: 'Exclusivos', icon: Sparkles },
    { id: 'new', label: 'Novos', icon: BadgeCheck },
    { id: 'featured', label: 'Recomendados', icon: Star },
    { id: 'dubbed', label: 'Dublados', icon: Globe },
  ];

  useEffect(() => {
    if (!authLoading) {
      if (!isAuthorized) {
        navigate('/');
      } else {
        fetchDoramas();
      }
    }
  }, [authLoading, isAuthorized, navigate]);

  const fetchDoramas = async () => {
    setLoadingData(true);
    try {
      const { data, error } = await supabase
        .from('doramas')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDoramas(data || []);
    } catch (error) {
      console.error('Error fetching doramas:', error);
      toast({
        title: "Erro ao carregar",
        description: "Não foi possível carregar a lista de doramas.",
        variant: "destructive"
      });
    } finally {
      setLoadingData(false);
    }
  };

  // Utility to create URL-friendly slugs
  const createSlug = (text) => {
    if (!text) return '';
    return text
      .toString()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim()
      .replace(/\s+/g, '-')
      .replace(/[^\w\-]+/g, '')
      .replace(/\-\-+/g, '-');
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;
    
    setFormData(prev => ({
      ...prev,
      [name]: newValue
    }));

    if (name === 'title') {
      const generated = createSlug(newValue);
      setEditingSlug(generated);
    }
  };

  const handleCoverFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setCoverFile(e.target.files[0]);
    }
  };

  const handleBannerFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setBannerFile(e.target.files[0]);
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      release_year: '',
      genres: '',
      cover_url: '',
      banner_url: '',
      bunny_embed_url: '',
      is_exclusive: false,
      is_new: false,
      is_featured: false,
      language: 'legendado'
    });
    setIsEditing(false);
    setEditingId(null);
    setEditingSlug('');
    setOriginalTitle('');
    setCoverFile(null);
    setBannerFile(null);
    
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (bannerInputRef.current) bannerInputRef.current.value = '';
  };

  const uploadImage = async (file, bucket = 'covers') => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `covers/${fileName}`; // Using 'covers' path structure within the bucket
    
    const { error: uploadError } = await supabase.storage
      .from(bucket)
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    const { data: publicUrlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(filePath);
      
    return publicUrlData?.publicUrl;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    let finalCoverUrl = formData.cover_url;
    let finalBannerUrl = formData.banner_url;

    try {
      // Upload Cover if new file selected
      if (coverFile) {
        finalCoverUrl = await uploadImage(coverFile, 'covers');
      }

      // Upload Banner if new file selected
      if (bannerFile) {
        finalBannerUrl = await uploadImage(bannerFile, 'covers'); // Reusing covers bucket as requested
      }

      const basePayload = {
        title: formData.title,
        description: formData.description,
        release_year: parseInt(formData.release_year) || new Date().getFullYear(),
        genres: formData.genres,
        cover_url: finalCoverUrl,
        banner_url: finalBannerUrl,
        bunny_embed_url: formData.bunny_embed_url,
        is_exclusive: formData.is_exclusive,
        is_new: formData.is_new,
        is_featured: formData.is_featured,
        language: formData.language
      };

      if (isEditing) {
        const updatePayload = { ...basePayload };
        
        if (formData.title !== originalTitle) {
          updatePayload.slug = createSlug(formData.title);
        }

        const { error } = await supabase
          .from('doramas')
          .update(updatePayload)
          .eq('id', editingId);

        if (error) throw error;
        toast({ title: "Sucesso", description: "Dorama atualizado com sucesso." });

      } else {
        const newSlug = createSlug(formData.title);
        
        const { data: existingSlug } = await supabase
          .from('doramas')
          .select('slug')
          .eq('slug', newSlug)
          .single();

        if (existingSlug) {
          toast({
            title: "Erro",
            description: "Já existe um dorama com este título/slug.",
            variant: "destructive"
          });
          return;
        }

        const createPayload = {
          ...basePayload,
          slug: newSlug
        };

        const { error } = await supabase
          .from('doramas')
          .insert([createPayload]);

        if (error) throw error;
        toast({ title: "Sucesso", description: "Dorama criado com sucesso." });
      }

      resetForm();
      fetchDoramas();
    } catch (error) {
      console.error('Error saving dorama:', error);
      toast({
        title: "Erro ao salvar",
        description: error.message || "Ocorreu um erro ao salvar o dorama.",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (dorama) => {
    setFormData({
      title: dorama.title || '',
      description: dorama.description || '',
      release_year: dorama.release_year || '',
      genres: dorama.genres || '',
      cover_url: dorama.cover_url || '',
      banner_url: dorama.banner_url || '',
      bunny_embed_url: dorama.bunny_embed_url || '',
      is_exclusive: dorama.is_exclusive || false,
      is_new: dorama.is_new || false,
      is_featured: dorama.is_featured || false,
      language: dorama.language || 'legendado'
    });
    setEditingId(dorama.id);
    setOriginalTitle(dorama.title || '');
    setEditingSlug(dorama.slug || '');
    setIsEditing(true);
    setCoverFile(null);
    setBannerFile(null);
    
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (bannerInputRef.current) bannerInputRef.current.value = '';
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Tem certeza que deseja excluir este dorama? Esta ação não pode ser desfeita.")) return;

    try {
      const { error } = await supabase
        .from('doramas')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      toast({ title: "Sucesso", description: "Dorama excluído com sucesso." });
      
      if (editingId === id) {
        resetForm();
      }
      
      fetchDoramas();
    } catch (error) {
      console.error('Error deleting dorama:', error);
      toast({
        title: "Erro ao excluir",
        description: "Não foi possível excluir o dorama.",
        variant: "destructive"
      });
    }
  };

  // Filter logic
  const filteredDoramas = doramas.filter(d => {
    // 1. Search Filter
    const matchesSearch = d.title?.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    // 2. Tab Filter
    switch (activeTab) {
      case 'exclusive': return d.is_exclusive;
      case 'new': return d.is_new;
      case 'featured': return d.is_featured;
      case 'dubbed': return d.language === 'dublado';
      case 'all':
      default: return true;
    }
  });

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white">
        Carregando...
      </div>
    );
  }

  if (!isAuthorized) {
    return null; 
  }

  return (
    <>
      <Helmet>
        <title>Painel Admin - DoramaStream</title>
      </Helmet>

      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8 font-sans">
        <div className="max-w-7xl mx-auto">
          
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-purple-400 mb-2">Painel de Doramas</h1>
            <p className="text-slate-400">Gerencie todos os doramas da plataforma.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Form */}
            <div className="lg:col-span-4">
              <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 sticky top-8">
                <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                  {isEditing ? <Edit className="w-5 h-5 text-blue-400" /> : <Plus className="w-5 h-5 text-green-400" />}
                  {isEditing ? "Editar Dorama" : "Novo Dorama"}
                </h2>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Título *</label>
                    <input
                      required
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                      placeholder="Ex: Vincenzo"
                    />
                  </div>

                  {/* Slug Preview */}
                  <div>
                    <label className="block text-sm font-medium text-slate-500 mb-1">Slug (Automático)</label>
                    <input
                      disabled
                      value={editingSlug}
                      className="w-full bg-slate-950/50 border border-slate-800/50 rounded-lg px-4 py-2 text-slate-500 cursor-not-allowed font-mono text-sm"
                    />
                    {isEditing && formData.title !== originalTitle && (
                      <p className="text-[10px] text-amber-500/80 mt-1">
                        O slug será atualizado automaticamente pois o título foi alterado.
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Ano de Lançamento</label>
                    <input
                      type="number"
                      name="release_year"
                      value={formData.release_year}
                      onChange={handleInputChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                      placeholder="Ex: 2021"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Gêneros</label>
                    <input
                      name="genres"
                      value={formData.genres}
                      onChange={handleInputChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                      placeholder="Ex: Ação, Crime, Romance"
                    />
                  </div>

                  {/* Flags & Language */}
                  <div className="space-y-4 pt-2 pb-2 border-y border-slate-800/50 my-2">
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer hover:text-purple-400 transition-colors">
                        <input
                          type="checkbox"
                          name="is_exclusive"
                          checked={formData.is_exclusive}
                          onChange={handleInputChange}
                          className="rounded border-slate-700 bg-slate-950 text-purple-500 focus:ring-purple-500"
                        />
                        <span className="text-sm text-slate-300 flex items-center gap-1">
                          <Sparkles className="w-3 h-3" /> Exclusivo
                        </span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer hover:text-green-400 transition-colors">
                        <input
                          type="checkbox"
                          name="is_new"
                          checked={formData.is_new}
                          onChange={handleInputChange}
                          className="rounded border-slate-700 bg-slate-950 text-green-500 focus:ring-green-500"
                        />
                        <span className="text-sm text-slate-300 flex items-center gap-1">
                          <BadgeCheck className="w-3 h-3" /> Novo Lançamento
                        </span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer hover:text-amber-400 transition-colors">
                        <input
                          type="checkbox"
                          name="is_featured"
                          checked={formData.is_featured}
                          onChange={handleInputChange}
                          className="rounded border-slate-700 bg-slate-950 text-amber-500 focus:ring-amber-500"
                        />
                        <span className="text-sm text-slate-300 flex items-center gap-1">
                          <Star className="w-3 h-3" /> Recomendado
                        </span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer hover:text-blue-400 transition-colors">
                        <input
                          type="checkbox"
                          checked={formData.language === 'dublado'}
                          onChange={(e) => {
                            setFormData(prev => ({
                              ...prev,
                              language: e.target.checked ? 'dublado' : 'legendado'
                            }));
                          }}
                          className="rounded border-slate-700 bg-slate-950 text-blue-500 focus:ring-blue-500"
                        />
                        <span className="text-sm text-slate-300 flex items-center gap-1">
                          <Globe className="w-3 h-3" /> Dublados
                        </span>
                      </label>
                    </div>
                  </div>

                  {/* Cover Upload */}
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Capa (Imagem Vertical)</label>
                    
                    {formData.cover_url && (
                      <div className="mb-2 relative w-24 h-36 bg-slate-950 rounded-md overflow-hidden border border-slate-800 shadow-sm group">
                        <img 
                          src={formData.cover_url} 
                          alt="Capa atual" 
                          className="w-full h-full object-cover" 
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-[10px] text-center py-1 text-white">Atual</div>
                      </div>
                    )}
                    
                    <div className="relative">
                      <input 
                        type="file" 
                        accept="image/*"
                        ref={fileInputRef}
                        onChange={handleCoverFileChange} 
                        className="w-full text-sm text-slate-400
                          file:mr-4 file:py-2 file:px-4
                          file:rounded-md file:border-0
                          file:text-xs file:font-semibold
                          file:bg-purple-900/50 file:text-purple-300
                          hover:file:bg-purple-900/70
                          bg-slate-950 rounded-lg border border-slate-800
                          cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Banner Upload (Optional) */}
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Banner Horizontal (Opcional)</label>
                    
                    {formData.banner_url && (
                      <div className="mb-2 relative w-full h-24 bg-slate-950 rounded-md overflow-hidden border border-slate-800 shadow-sm group">
                        <img 
                          src={formData.banner_url} 
                          alt="Banner atual" 
                          className="w-full h-full object-cover" 
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-[10px] text-center py-1 text-white">Atual</div>
                        <button
                          type="button"
                          onClick={() => setFormData(prev => ({ ...prev, banner_url: '' }))}
                          className="absolute top-1 right-1 bg-black/60 rounded-full p-1 text-white hover:bg-red-600 transition-colors"
                          title="Remover banner"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                    
                    <div className="relative">
                      <input 
                        type="file" 
                        accept="image/*"
                        ref={bannerInputRef}
                        onChange={handleBannerFileChange} 
                        className="w-full text-sm text-slate-400
                          file:mr-4 file:py-2 file:px-4
                          file:rounded-md file:border-0
                          file:text-xs file:font-semibold
                          file:bg-blue-900/50 file:text-blue-300
                          hover:file:bg-blue-900/70
                          bg-slate-950 rounded-lg border border-slate-800
                          cursor-pointer"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Bunny Embed URL</label>
                    <input
                      name="bunny_embed_url"
                      value={formData.bunny_embed_url}
                      onChange={handleInputChange}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-xs"
                      placeholder="https://iframe.mediadelivery.net/embed/..."
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Descrição</label>
                    <textarea
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      rows={4}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                      placeholder="Sinopse do dorama..."
                    />
                  </div>

                  <div className="pt-4 flex flex-col gap-3">
                    <div className="flex gap-3">
                      <Button 
                        type="submit" 
                        className={`flex-1 ${isEditing ? 'bg-blue-600 hover:bg-blue-700' : 'bg-green-600 hover:bg-green-700'} text-white`}
                      >
                        {isEditing ? (
                          <><Save className="w-4 h-4 mr-2" /> Salvar Alterações</>
                        ) : (
                          <><Plus className="w-4 h-4 mr-2" /> Criar Dorama</>
                        )}
                      </Button>
                      
                      {isEditing && (
                        <Button 
                          type="button"
                          variant="outline"
                          onClick={resetForm}
                          className="border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                    
                    {isEditing && (
                      <Button
                        type="button"
                        variant="destructive"
                        onClick={() => handleDelete(editingId)}
                        className="w-full bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-900/50"
                      >
                        <Trash2 className="w-4 h-4 mr-2" /> Excluir Dorama
                      </Button>
                    )}
                  </div>
                </form>
              </div>
            </div>

            {/* Right Column: List */}
            <div className="lg:col-span-8">
              <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 h-full flex flex-col">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                  <h2 className="text-xl font-semibold">Catálogo ({filteredDoramas.length})</h2>
                  
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Buscar por título..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>

                {/* Filter Tabs */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {filterTabs.map((tab) => {
                    const TabIcon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={cn(
                          "px-3 py-1.5 rounded-full text-xs font-medium transition-colors flex items-center gap-1.5 border",
                          activeTab === tab.id
                            ? "bg-purple-600 text-white border-purple-500"
                            : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-slate-200"
                        )}
                      >
                        <TabIcon className="w-3.5 h-3.5" />
                        {tab.label}
                      </button>
                    );
                  })}
                </div>

                {loadingData ? (
                  <div className="text-center py-12 text-slate-500 animate-pulse">Carregando lista...</div>
                ) : filteredDoramas.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">Nenhum dorama encontrado.</div>
                ) : (
                  <div className="grid gap-4">
                    {filteredDoramas.map((dorama) => (
                      <div 
                        key={dorama.id} 
                        onClick={() => handleEdit(dorama)}
                        className={`flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-slate-950 p-4 rounded-lg border cursor-pointer transition-all
                          ${editingId === dorama.id ? 'border-blue-500 ring-1 ring-blue-500/30 bg-slate-900' : 'border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'}
                        `}
                      >
                        {/* Thumbnail */}
                        <div className="w-full sm:w-16 h-24 sm:h-20 bg-slate-900 rounded-md overflow-hidden flex-shrink-0 border border-slate-800 relative">
                          {dorama.cover_url ? (
                            <img src={dorama.cover_url} alt={dorama.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs text-slate-600 bg-slate-900">
                              <ImageIcon className="w-6 h-6 text-slate-700" />
                            </div>
                          )}
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className={`font-bold truncate ${editingId === dorama.id ? 'text-blue-400' : 'text-slate-200'}`}>
                                {dorama.title}
                              </h3>
                              <p className="text-sm text-slate-500 truncate">
                                {dorama.release_year || 'Ano N/A'} • {dorama.genres || 'Sem Gênero'}
                              </p>
                            </div>
                            
                            {/* Banner Icon Indicator */}
                            {dorama.banner_url && (
                               <div title="Possui Banner" className="text-blue-500">
                                 <MonitorPlay className="w-4 h-4" />
                               </div>
                            )}
                          </div>

                          {/* Badges Row */}
                          <div className="flex flex-wrap gap-2">
                            {dorama.is_exclusive && (
                              <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/20 rounded flex items-center gap-1">
                                <Sparkles className="w-3 h-3" /> Exclusivo
                              </span>
                            )}
                            {dorama.is_new && (
                              <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-green-500/10 text-green-400 border border-green-500/20 rounded flex items-center gap-1">
                                <BadgeCheck className="w-3 h-3" /> Novo
                              </span>
                            )}
                            {dorama.is_featured && (
                              <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded flex items-center gap-1">
                                <Star className="w-3 h-3" /> Recomendado
                              </span>
                            )}
                            {dorama.language === 'dublado' ? (
                              <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded flex items-center gap-1">
                                <Globe className="w-3 h-3" /> Dublado
                              </span>
                            ) : (
                              <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-slate-700/30 text-slate-400 border border-slate-700/50 rounded">
                                Legendado
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Indicator */}
                        <div className="hidden sm:block">
                          {editingId === dorama.id ? (
                            <div className="text-xs bg-blue-900/30 text-blue-400 px-2 py-1 rounded border border-blue-800/50">
                              Editando
                            </div>
                          ) : (
                            <Edit className="w-4 h-4 text-slate-600 opacity-0 group-hover:opacity-100" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  );
}