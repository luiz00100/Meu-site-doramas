import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

import Navbar from '@/components/Navbar';
import DoramaCard from '@/components/DoramaCard';
import WelcomeMessage from '@/components/WelcomeMessage';

import { Button } from '@/components/ui/button';
import {
  Play,
  Info,
  ArrowLeft,
  ArrowRight,
  Loader2,
  ServerCrash,
  Sparkles,
  Star,
  Globe,
  BadgeCheck,
} from 'lucide-react';

// ---------------- HERO --------------------

const HeroSection = ({ featuredDoramas, loading }) => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleNext = useCallback(() => {
    setCurrentIndex((prev) =>
      prev === featuredDoramas.length - 1 ? 0 : prev + 1
    );
  }, [featuredDoramas.length]);

  const handlePrev = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? featuredDoramas.length - 1 : prev - 1
    );
  };

  useEffect(() => {
    if (featuredDoramas.length > 1) {
      const timer = setInterval(handleNext, 7000);
      return () => clearInterval(timer);
    }
  }, [featuredDoramas.length, handleNext]);

  const handleWatchClick = (slug) => {
    if (!isAuthenticated) navigate('/login');
    else navigate(`/dorama/${slug}`);
  };

  if (loading) {
    return (
      <div className="relative w-full h-[50vh] md:h-[70vh] bg-slate-900 flex items-center justify-center rounded-lg overflow-hidden">
        <Loader2 className="w-10 h-10 animate-spin text-purple-400" />
      </div>
    );
  }

  if (!featuredDoramas || featuredDoramas.length === 0) return null;

  const currentDorama = featuredDoramas[currentIndex];
  if (!currentDorama) return null;

  const imageUrl =
    currentDorama.banner_url ||
    currentDorama.cover_url ||
    '';

  const linkTarget = `/dorama/${currentDorama.slug}`;

  // -------- MOBILE HERO --------
  const MobileHeroContent = () => (
    <div className="md:hidden relative w-full h-full">
      {/* Fundo com imagem */}
      {imageUrl && (
        <img
          src={imageUrl}
          alt={currentDorama.title}
          className="absolute inset-0 w-full h-full object-cover"
        />
      )}

      {/* Overlay de gradiente pra leitura */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/70 to-transparent" />

      {/* Conteúdo */}
      <div className="relative z-10 flex flex-col justify-end h-full px-4 pb-6 pt-16 space-y-3">
        <h2 className="text-2xl font-bold text-white line-clamp-2">
          {currentDorama.title}
        </h2>

        <p className="text-sm text-slate-200 line-clamp-3">
          {currentDorama.description}
        </p>

        <div className="flex gap-3 mt-3">
          <Button
            onClick={() => handleWatchClick(currentDorama.slug)}
            className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg"
            size="lg"
          >
            <Play className="w-5 h-5 mr-2 fill-white" /> Assistir agora
          </Button>

          <Button
            onClick={() => navigate(linkTarget)}
            variant="outline"
            className="flex-1 border-slate-700 text-slate-100 hover:bg-slate-900/60 py-3 rounded-lg"
            size="lg"
          >
            <Info className="w-5 h-5 mr-2" /> Detalhes
          </Button>
        </div>

        {/* bolinhas do carrossel */}
        {featuredDoramas.length > 1 && (
          <div className="flex items-center justify-center gap-2 mt-3">
            {featuredDoramas.map((_, index) => (
              <button
                key={index}
                className={`h-2 w-2 rounded-full transition-all ${
                  currentIndex === index
                    ? 'w-4 bg-purple-500'
                    : 'bg-slate-500/60'
                }`}
                onClick={() => setCurrentIndex(index)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );

  // -------- DESKTOP HERO --------
  const DesktopHeroContent = () => (
    <AnimatePresence mode="wait">
      <motion.div
        key={currentIndex}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="absolute inset-0"
      >
        <img
          src={imageUrl}
          alt={currentDorama.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-slate-950/70 to-transparent" />
      </motion.div>

      <div className="relative z-10 flex items-center justify-between h-full p-8 md:p-12 lg:p-16">
        <div className="w-full lg:w-1/2 text-white">
          <motion.h1
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
          >
            {currentDorama.title}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-slate-300 mb-8"
          >
            {currentDorama.description}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex items-center gap-4"
          >
            <Button
              onClick={() => handleWatchClick(currentDorama.slug)}
              className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg"
              size="lg"
            >
              <Play className="w-5 h-5 mr-2 fill-white" /> Assistir agora
            </Button>

            <Button
              onClick={() => navigate(linkTarget)}
              variant="outline"
              className="border-slate-700 text-slate-300 hover:bg-slate-800 text-lg px-6 py-5 rounded-lg"
              size="lg"
            >
              <Info className="w-5 h-5 mr-2" /> Mais Detalhes
            </Button>
          </motion.div>
        </div>

        {/* CARD AJUSTADO (15% mais largo, 15% menor) */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 0.85 }} // 15% menor
          transition={{ duration: 0.5, delay: 0.3 }}
          className="hidden lg:flex justify-center items-center w-[275px]" // 15% mais largo
        >
          <DoramaCard dorama={currentDorama} />
        </motion.div>
      </div>

      {/* Setas desktop */}
      {featuredDoramas.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-2 bg-black/30 hover:bg-black/60 rounded-full hidden md:block"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>

          <button
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-2 bg-black/30 hover:bg-black/60 rounded-full hidden md:block"
          >
            <ArrowRight className="w-6 h-6 text-white" />
          </button>
        </>
      )}
    </AnimatePresence>
  );

  return (
    <section className="relative w-full h-[65vh] md:h-[70vh] rounded-lg overflow-hidden home-hero">
      {/* Mobile hero */}
      <MobileHeroContent />

      {/* Desktop hero */}
      <div className="relative w-full h-full hidden md:block">
        <DesktopHeroContent />
      </div>

      {/* Setas no MOBILE */}
      {featuredDoramas.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            className="absolute left-2 top-1/2 -translate-y-1/2 z-20 p-2 bg-black/40 hover:bg-black/70 rounded-full md:hidden"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>

          <button
            onClick={handleNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 z-20 p-2 bg-black/40 hover:bg-black/70 rounded-full md:hidden"
          >
            <ArrowRight className="w-5 h-5 text-white" />
          </button>
        </>
      )}
    </section>
  );
};

// ---------------- SEÇÕES --------------------

const DoramaSection = ({ title, icon, doramas, loading, error, id }) => (
  <section id={id} className="py-8 md:py-12">
    <div className="flex items-center gap-3 mb-6">
      {icon}
      <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
    </div>

    {loading ? (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className="aspect-[2/3] bg-slate-800 rounded-lg animate-pulse"
          ></div>
        ))}
      </div>
    ) : error ? (
      <div className="bg-slate-900 border border-red-500/30 rounded-lg p-6 text-center text-red-400">
        <ServerCrash className="mx-auto w-8 h-8 mb-2" />
        Não foi possível carregar esta seção.
      </div>
    ) : (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
        {doramas.map((dorama, index) => (
          <DoramaCard key={dorama.id} dorama={dorama} index={index} />
        ))}
      </div>
    )}
  </section>
);

// ---------------- DASHBOARD --------------------

const Dashboard = ({ searchQuery, setSearchQuery }) => {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [doramas, setDoramas] = useState({
    featured: [],
    exclusive: [],
    new: [],
    recommended: [],
    dubbed: [],
  });

  const [loading, setLoading] = useState({
    featured: true,
    exclusive: true,
    new: true,
    recommended: true,
    dubbed: true,
  });

  const [error, setError] = useState({
    featured: false,
    exclusive: false,
    new: false,
    recommended: false,
    dubbed: false,
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) navigate('/login');
  }, [isAuthenticated, authLoading, navigate]);

  const fetchData = useCallback(async (category, query) => {
    try {
      const { data, error } = await query;
      if (error) throw error;
      setDoramas((prev) => ({ ...prev, [category]: data || [] }));
    } catch (err) {
      setError((prev) => ({ ...prev, [category]: true }));
    } finally {
      setLoading((prev) => ({ ...prev, [category]: false }));
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      fetchData(
        'featured',
        supabase
          .from('doramas')
          .select('*')
          .order('is_featured', { ascending: false })
          .order('created_at', { ascending: false })
          .limit(5)
      );

      fetchData(
        'exclusive',
        supabase
          .from('doramas')
          .select('*')
          .eq('is_exclusive', true)
          .limit(12)
      );
      fetchData(
        'new',
        supabase.from('doramas').select('*').eq('is_new', true).limit(12)
      );
      fetchData(
        'recommended',
        supabase
          .from('doramas')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(12)
      );
      fetchData(
        'dubbed',
        supabase
          .from('doramas')
          .select('*')
          .eq('language', 'dubbed')
          .limit(12)
      );
    }
  }, [isAuthenticated, fetchData]);

  const filteredDoramas = useMemo(() => {
    const all = [
      ...doramas.exclusive,
      ...doramas.new,
      ...doramas.recommended,
      ...doramas.dubbed,
    ];

    if (!searchQuery) return null;

    const unique = all.filter(
      (d, i, self) => i === self.findIndex((x) => x.id === d.id)
    );

    return unique.filter(
      (d) =>
        d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (d.genres &&
          typeof d.genres === 'string' &&
          d.genres.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [doramas, searchQuery]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard - DoramaStream</title>
      </Helmet>

      <Navbar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <WelcomeMessage user={user} />

        {searchQuery ? (
          <section className="py-8 md:py-12">
            <h2 className="text-2xl md:text-3xl font-bold mb-6">
              Resultados para "{searchQuery}"
            </h2>

            {filteredDoramas && filteredDoramas.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
                {filteredDoramas.map((dorama, index) => (
                  <DoramaCard key={dorama.id} dorama={dorama} index={index} />
                ))}
              </div>
            ) : (
              <p className="text-slate-400">Nenhum resultado encontrado.</p>
            )}
          </section>
        ) : (
          <>
            <HeroSection
              featuredDoramas={doramas.featured}
              loading={loading.featured}
            />

            <DoramaSection
              id="section-exclusivos"
              title="Exclusivos DoramaStream"
              icon={<Sparkles className="w-6 h-6 text-purple-400" />}
              doramas={doramas.exclusive}
              loading={loading.exclusive}
              error={error.exclusive}
            />

            <DoramaSection
              id="section-novos"
              title="Novos Episódios"
              icon={<BadgeCheck className="w-6 h-6 text-green-400" />}
              doramas={doramas.new}
              loading={loading.new}
              error={error.new}
            />

            <DoramaSection
              id="section-recomendados"
              title="Recomendados para Você"
              icon={<Star className="w-6 h-6 text-amber-400" />}
              doramas={doramas.recommended}
              loading={loading.recommended}
              error={error.recommended}
            />

            <DoramaSection
              id="section-dublados"
              title="Doramas Dublados"
              icon={<Globe className="w-6 h-6 text-blue-400" />}
              doramas={doramas.dubbed}
              loading={loading.dubbed}
              error={error.dubbed}
            />
          </>
        )}
      </main>
    </>
  );
};

export default Dashboard;
