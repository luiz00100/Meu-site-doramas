const WelcomeMessage = () => {
  return null;
};

export default WelcomeMessage;