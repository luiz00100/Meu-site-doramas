import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Play,
  User,
  LogOut,
  Menu,
  X,
  Sparkles,
  Star,
  Globe,
  BadgeCheck,
  ChevronDown,
  Search,
  Settings,
  CreditCard,
  Calendar,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/supabaseClient';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navbar = ({ searchQuery, setSearchQuery }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();

  const ADMIN_EMAIL = "tessuportegeral@gmail.com";
  const isAdmin = user?.email === ADMIN_EMAIL;

  // 🔔 Estado da assinatura (pra mostrar no menu e no desktop)
  const [subLoading, setSubLoading] = useState(false);
  const [subscription, setSubscription] = useState(null);

  useEffect(() => {
    if (!user) {
      setSubscription(null);
      return;
    }

    const fetchSub = async () => {
      try {
        setSubLoading(true);
        const { data, error } = await supabase
          .from('subscriptions')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (error) throw error;
        setSubscription(data || null);
      } catch (err) {
        console.error('Erro ao carregar assinatura no menu:', err);
        setSubscription(null);
      } finally {
        setSubLoading(false);
      }
    };

    fetchSub();
  }, [user]);

  const formatDate = (value) => {
    if (!value) return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return null;
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const nextBilling =
    formatDate(subscription?.current_period_end) ||
    formatDate(subscription?.expires_at) ||
    null;

  const planName =
    subscription?.plan_name ||
    subscription?.price_nickname ||
    null;

  const statusLabel = subscription?.status || null;

  const handleLogout = async () => {
    try {
      setMobileMenuOpen(false);

      await supabase.auth.signOut();

      toast({
        title: 'Desconectado com sucesso',
        description: 'Até logo!',
      });

      navigate('/');

      setTimeout(() => {
        window.location.reload();
      }, 150);
    } catch (err) {
      toast({
        title: 'Erro ao desconectar',
        description: err.message,
        variant: 'destructive',
      });
    }
  };

  const scrollToSection = (sectionId) => {
    const scrollAction = () => {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    };

    if (location.pathname !== '/dashboard') {
      navigate('/dashboard');
      setTimeout(scrollAction, 500);
    } else {
      scrollAction();
    }

    setMobileMenuOpen(false);
  };

  const displayName = user?.user_metadata?.name || user?.email || 'Usuário';
  const showSearch = isAuthenticated && location.pathname === '/dashboard';

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/95 backdrop-blur-sm border-b border-slate-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* HEADER ROW */}
        <div className="flex items-center justify-between h-16">
          {/* LOGO */}
          <Link
            to={isAuthenticated ? '/dashboard' : '/'}
            className="flex items-center space-x-2 group"
          >
            <motion.div
              whileHover={{ scale: 1.1, rotate: 360 }}
              transition={{ duration: 0.3 }}
            >
              <Play className="w-8 h-8 text-purple-500 fill-purple-500" />
            </motion.div>
            <span className="text-xl font-bold text-gradient">DormaPlus</span>
          </Link>

          {/* SEARCH (DESKTOP) */}
          <div className="flex-1 flex justify-center px-4">
            {showSearch && (
              <div className="w-full max-w-sm hidden md:block">
                <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-3 py-1.5">
                  <Search className="w-4 h-4 text-white/50" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar..."
                    className="bg-transparent border-none outline-none text-xs md:text-sm text-white/90 w-full placeholder:text-white/50"
                  />
                </div>
              </div>
            )}
          </div>

          {/* MENU DESKTOP */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                {/* DROPDOWN CATEGORIAS */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="text-slate-300 hover:text-white flex items-center gap-1"
                    >
                      Categorias <ChevronDown className="w-4 h-4 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-slate-900 border-slate-800 text-slate-200 w-56 p-2">
                    <DropdownMenuItem onClick={() => scrollToSection('section-exclusivos')}>
                      <Sparkles className="w-4 h-4 text-purple-400" /> Exclusivos
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => scrollToSection('section-novos')}>
                      <BadgeCheck className="w-4 h-4 text-green-400" /> Novos
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => scrollToSection('section-recomendados')}>
                      <Star className="w-4 h-4 text-amber-400" /> Recomendados
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => scrollToSection('section-dublados')}>
                      <Globe className="w-4 h-4 text-blue-400" /> Dublados
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* ADMIN DESKTOP */}
                {isAdmin && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="text-slate-300 hover:text-white">
                        <Settings className="w-6 h-6" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-slate-900 border-slate-800 text-slate-200 w-48 p-2">
                      <DropdownMenuItem onClick={() => navigate('/admin/dashboard')}>
                        Painel Admin
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate('/admin/doramas')}>
                        Gerenciar Doramas
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}

                {/* USER + ASSINATURA + SAIR (DESKTOP) */}
                <div className="flex items-center space-x-3 pl-4 border-l border-slate-700">
                  <User className="w-5 h-5 text-purple-400" />
                  <div className="flex flex-col">
                    <span className="text-sm text-slate-300">{displayName}</span>

                    {/* Mini-linha de status no desktop */}
                    {!subLoading && subscription && (
                      <span className="text-xs text-slate-400">
                        {planName && `${planName} • `}
                        {nextBilling && `vence em ${nextBilling}`}
                      </span>
                    )}
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" /> Sair
                  </Button>
                </div>
              </>
            ) : (
              <>
                <Link to="/login"><Button variant="ghost">Entrar</Button></Link>
                <Link to="/signup"><Button className="bg-purple-600 hover:bg-purple-700">Cadastrar</Button></Link>
              </>
            )}
          </div>

          {/* BOTÃO MENU MOBILE */}
          <button
            className="md:hidden text-slate-300 hover:text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* MENU MOBILE */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800 bg-slate-950/98">
          <div className="container mx-auto px-4 py-3 space-y-4">

            {/* SEARCH MOBILE */}
            {showSearch && (
              <div className="w-full">
                <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-3 py-1.5">
                  <Search className="w-4 h-4 text-white/50" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar..."
                    className="bg-transparent border-none outline-none text-sm text-white/90 w-full placeholder:text-white/50"
                  />
                </div>
              </div>
            )}

            {isAuthenticated ? (
              <>
                {/* CATEGORIAS */}
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => scrollToSection('section-exclusivos')}
                    className="flex items-center gap-2 text-slate-200 text-sm"
                  >
                    <Sparkles className="w-4 h-4 text-purple-400" /> Exclusivos
                  </button>
                  <button
                    onClick={() => scrollToSection('section-novos')}
                    className="flex items-center gap-2 text-slate-200 text-sm"
                  >
                    <BadgeCheck className="w-4 h-4 text-green-400" /> Novos
                  </button>
                  <button
                    onClick={() => scrollToSection('section-recomendados')}
                    className="flex items-center gap-2 text-slate-200 text-sm"
                  >
                    <Star className="w-4 h-4 text-amber-400" /> Recomendados
                  </button>
                  <button
                    onClick={() => scrollToSection('section-dublados')}
                    className="flex items-center gap-2 text-slate-200 text-sm"
                  >
                    <Globe className="w-4 h-4 text-blue-400" /> Dublados
                  </button>
                </div>

                {/* ADMIN MOBILE */}
                {isAdmin && (
                  <div className="pt-2 border-t border-slate-800 mt-2">
                    <p className="text-xs text-slate-500 mb-1">Admin</p>
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        navigate('/admin/dashboard');
                      }}
                      className="text-slate-200 text-sm text-left"
                    >
                      Painel Admin
                    </button>
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        navigate('/admin/doramas');
                      }}
                      className="text-slate-200 text-sm text-left mt-2"
                    >
                      Gerenciar Doramas
                    </button>
                  </div>
                )}

                {/* USER + SAIR */}
                <div className="pt-3 border-t border-slate-800 mt-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User className="w-5 h-5 text-purple-400" />
                    <span className="text-sm text-slate-200">{displayName}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleLogout}
                    className="text-red-400 hover:text-red-300 flex items-center gap-1"
                  >
                    <LogOut className="w-4 h-4" /> Sair
                  </Button>
                </div>

                {/* 🔥 STATUS DA ASSINATURA NO MENU MOBILE */}
                <div className="mt-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-200 flex gap-3">
                  <div className="mt-1">
                    <CreditCard className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">
                      Status da sua assinatura
                    </p>

                    {subLoading ? (
                      <p className="text-slate-400 mt-1">
                        Carregando...
                      </p>
                    ) : !subscription ? (
                      <p className="text-slate-400 mt-1">
                        Você ainda não possui uma assinatura ativa.
                      </p>
                    ) : (
                      <>
                        {planName && (
                          <p className="mt-1">
                            Plano: <span className="font-semibold text-white">{planName}</span>
                          </p>
                        )}

                        {statusLabel && (
                          <p className="mt-1">
                            Status{' '}
                            <span
                              className={
                                statusLabel === 'active'
                                  ? 'text-green-400 font-semibold'
                                  : 'text-amber-300 font-semibold'
                              }
                            >
                              {statusLabel}
                            </span>
                          </p>
                        )}

                        {nextBilling && (
                          <p className="mt-1 flex items-center gap-1">
                            <Calendar className="w-4 h-4 text-slate-400" />
                            Vencimento:{' '}
                            <span className="font-semibold text-white">
                              {nextBilling}
                            </span>
                          </p>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </>
            ) : (
              // NÃO AUTENTICADO MOBILE
              <div className="flex flex-col gap-2">
                <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-center">
                    Entrar
                  </Button>
                </Link>
                <Link to="/signup" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">
                    Cadastrar
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
