import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from 'react';
import { supabase } from '@/lib/supabaseClient';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const [isPremium, setIsPremium] = useState(false);
  const [checkingPremium, setCheckingPremium] = useState(true);

  // Checa na tabela subscriptions se o usuário tem plano ativo
  const checkPremiumStatus = useCallback(async (userId) => {
    if (!userId) {
      setIsPremium(false);
      setCheckingPremium(false);
      return;
    }

    setCheckingPremium(true);

    try {
      const { data: subscriptions, error } = await supabase
        .from('subscriptions')
        .select('status, end_at, current_period_end')
        .eq('user_id', userId)
        .in('status', ['active', 'trialing']);

      if (error) throw error;

      const now = new Date();
      const subs = subscriptions || [];

      const hasActiveSub = subs.some((sub) => {
        const endDate = sub.end_at || sub.current_period_end;
        return endDate && new Date(endDate) > now;
      });

      setIsPremium(hasActiveSub);
    } catch (err) {
      console.error('Error checking premium status:', err);
      setIsPremium(false);
    } finally {
      setCheckingPremium(false);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;

    const initSession = async () => {
      try {
        setLoading(true);

        // 🔹 Pega a sessão inicial ao carregar a aplicação
        const {
          data: { session },
          error,
        } = await supabase.auth.getSession();

        if (error) {
          console.error('Error getting initial session:', error);
        }

        if (!isMounted) return;

        setSession(session ?? null);
        const currentUser = session?.user ?? null;
        setUser(currentUser);

        if (currentUser) {
          // checa premium para o usuário logado
          checkPremiumStatus(currentUser.id);
        } else {
          setIsPremium(false);
          setCheckingPremium(false);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    initSession();

    // 🔹 Escuta mudanças de auth (login/logout/refresh)
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      if (!isMounted) return;

      const currentUser = session?.user ?? null;
      setSession(session ?? null);
      setUser(currentUser);

      if (currentUser) {
        // recomendação da Supabase: NÃO usar await/supabase direto aqui,
        // joga para depois com setTimeout
        setTimeout(() => {
          checkPremiumStatus(currentUser.id);
        }, 0);
      } else {
        setIsPremium(false);
        setCheckingPremium(false);
      }

      // depois de qualquer mudança de auth, paramos o loading do auth
      setLoading(false);
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, [checkPremiumStatus]);

  const refreshPremiumStatus = useCallback(() => {
    if (user) {
      checkPremiumStatus(user.id);
    }
  }, [user, checkPremiumStatus]);

  const value = {
    user,
    session,
    loading,
    isAuthenticated: !!user,
    isPremium,
    checkingPremium,
    refreshPremiumStatus,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
